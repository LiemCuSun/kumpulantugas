let date = new Date
console.log(`Hari ini tanggal ${date.getDate()} - ${date.getMonth()+1} - ${date.getFullYear()}
Besok tanggal ${date.getDate()+1} - ${date.getMonth()+1} - ${date.getFullYear()} 
Kemarin tanggal ${date.getDate()-1} - ${date.getMonth()+1} - ${date.getFullYear()}`)
